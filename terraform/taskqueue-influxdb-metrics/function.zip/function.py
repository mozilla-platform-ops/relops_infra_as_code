#!/usr/bin/env python

# python3 -m pip install influxdb